
package sortingarray;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.Arrays;
public class Sortingarray {

    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("type in 10 numbers but press enter after each number inputted");
        //creates the array and alocates a number of spaces inside it
        int[] myArray = new int[10];
      double average = 0.0;
      
      System.out.println("Type in 10 numbers (press enter after each ");
      
      for(int i = 0; i < myArray.length; i++){
          if (i<=10){
              myArray[i] = input.nextInt();
              average = average + myArray[i];
              
              
              
              
              
          }
          
      }
      //this is the sorting logic received from javapoint.com
        for (int i = 0; i < myArray.length; i++){
               for(int j = i+1; j < myArray.length; j++){
                   int tmp = 0;
                   if(myArray[i] > myArray[j]){
                       tmp = myArray[i];
                       myArray[i] = myArray[j];
                       myArray[j] = tmp;
                       
                       System.out.println(Arrays.toString(myArray));
                   }
                       }   
              }
        int largest = Integer.MIN_VALUE;
        int index = 0;
        while( index < myArray.length){
            if (largest < myArray[index] ){
            largest = myArray[index];
        }
            index++;
            
        }
        
        int index2 = 0;
        //largest possible value
        int smallest = Integer.MAX_VALUE;
        while( index2 < myArray.length){
            //checks to see if the smallest is greater then element?
            if (smallest > myArray[index2] ){
                //saves the smallest number in the array as smallest
            smallest = myArray[index2];
        }
            index2++;
            
        }
        
        int add = 0;
        for(int i = 0; i <myArray.length; i++){
            add+= myArray[i];
           
            
           
            // You need to increment the index at the end of the loop.
}
       
        
       int Divide = (add/myArray.length);
        System.out.println("this is the average number:" +Divide);
        System.out.println("the largest number is:" + largest );
        System.out.println("the smallest number is:" + smallest );
    }
    
   
       
              
    }

    

